<?php
//Remove a todo task to $todos PHP array
?>