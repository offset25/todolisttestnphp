<?php
//Add a todo task to $todos PHP array
?>